#ifndef _VIEW_H
#define _VIEW_H 

// Jamie, feel free to do whatever you want/need to design the SDL below.

/*
  Displays an Undersea Invaders game as a Simple DirectMedia Layer.
*/

class UnderSeaInvadersView{
  public:
  // TODO (Checkpoint 1)
  private:
  // TODO (Checkpoint 1)
};

#endif