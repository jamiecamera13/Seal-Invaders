#include "Controller.h"

/*
  Implements operations in an UnderSeaInvadersController.
*/

UnderSeaInvadersController::UnderSeaInvadersController(){}
UnderSeaInvadersController::~UnderSeaInvadersController(){}
// TODO (Checkpoint 2)